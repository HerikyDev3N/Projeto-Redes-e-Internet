document.addEventListener("DOMContentLoaded", function() {
    var scrollLinks = document.querySelectorAll('.scroll-to');

    scrollLinks.forEach(function(scrollLink) {
        scrollLink.addEventListener('click', function(event) {
            event.preventDefault();
            
            var targetId = this.getAttribute('href').substring(1);
            var targetSection = document.getElementById(targetId);
            
            if (targetSection) {
                var offsetTop = targetSection.offsetTop - 70; // Ajuste opcional para compensar o tamanho da navbar fixa
                window.scroll({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Outras funções (contador, validação de formulário, etc.) aqui
});
