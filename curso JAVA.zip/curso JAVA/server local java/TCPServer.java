import java.io.*;
import java.net.*;

public class TCPServer {
    public static void main(String[] args) {
        int port = 50000;

        try {
            ServerSocket serverSocket = new ServerSocket(port);
            System.out.println("Servidor na escuta em " + InetAddress.getLocalHost().getHostAddress() + ":" + port);

            Socket clientSocket = serverSocket.accept();
            System.out.println("Conectado com o cliente: " + clientSocket.getInetAddress().getHostAddress());

            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                System.out.println("Mensagem recebida: " + inputLine);
                out.println(inputLine);
            }

            clientSocket.close();
            serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
