import java.io.*;
import java.net.*;

public class TCPClient {
    public static void main(String[] args) {
        String host = "127.0.0.1";
        int port = 50000;

        try {
            Socket socket = new Socket(host, port);

            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            System.out.println("Conectado ao servidor.");

            String message;
            while (true) {
                System.out.print("Digite a mensagem que deseja enviar (Digite 'Sair' para encerrar): ");
                message = input.readLine();
                if (message.equalsIgnoreCase("Sair")) {
                    break;
                }
                out.println(message);
                System.out.println("Mensagem recebida de volta do Servidor: " + in.readLine());
            }

            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
